using System;
using System.Collections.Generic;

namespace SwinAdventure
{
    public class Swinadventure
    {
        static void Main(string[]args)
        {
            Console.WriteLine("Hello World");
        }
    }
}